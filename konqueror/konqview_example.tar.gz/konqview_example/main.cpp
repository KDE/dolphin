#include <kapp.h>
#include <qlabel.h>
#include <klocale.h>

/*
 * In a real view you would do something a little more useful here. Since we
 * are only doing a KParts/Browser view example we just show a little label
 * if run manually.
 */
int main(int argc, char **argv)
{
    KApplication app(argc, argv, "ksimpleview");
    QLabel *lbl = new QLabel(i18n("KDE Tutorial Example View"), NULL);
    app.setMainWidget(lbl);
    lbl->resize(lbl->sizeHint());
    lbl->show();
    return(app.exec());
}