/*
 *  MICO --- a free CORBA implementation
 *  Copyright (C) 1997-98 Kay Roemer & Arno Puder
 *
 *  This file was automatically generated. DO NOT EDIT!
 */

#include <kfm.h>

//--------------------------------------------------------
//  Implementation of stubs
//--------------------------------------------------------

// Stub interface Part
KFM::Part::~Part()
{
}

KFM::Part_ptr KFM::Part::_duplicate( Part_ptr _obj )
{
  if( !CORBA::is_nil( _obj ) )
    _obj->_ref();
  return _obj;
}

void *KFM::Part::_narrow_helper( const char *_repoid )
{
  if( strcmp( _repoid, "IDL:KFM/Part:1.0" ) == 0 )
    return (void *)this;
  {
    void *_p;
    if( (_p = OpenParts::Part::_narrow_helper( _repoid )))
      return _p;
  }
  return NULL;
}

bool KFM::Part::_narrow_helper2( CORBA::Object_ptr _obj )
{
  if( strcmp( _obj->_repoid(), "IDL:KFM/Part:1.0" ) == 0) {
    return true;
  }
  for( vector<CORBA::Narrow_proto>::size_type _i = 0;
       _narrow_helpers && _i < _narrow_helpers->size(); _i++ ) {
    bool _res = (*(*_narrow_helpers)[ _i ])( _obj );
    if( _res )
      return true;
  }
  return false;
}

KFM::Part_ptr KFM::Part::_narrow( CORBA::Object_ptr _obj )
{
  KFM::Part_ptr _o;
  if( !CORBA::is_nil( _obj ) ) {
    void *_p;
    if( (_p = _obj->_narrow_helper( "IDL:KFM/Part:1.0" )))
      return _duplicate( (KFM::Part_ptr) _p );
    if( _narrow_helper2( _obj ) ) {
      _o = new KFM::Part_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
    if( _obj->_is_a_remote( "IDL:KFM/Part:1.0" ) ) {
      _o = new KFM::Part_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
  }
  return _nil();
}

KFM::Part_ptr KFM::Part::_nil()
{
  return NULL;
}

KFM::Part_stub::~Part_stub()
{
}

void KFM::Part_stub::openURL( const char* url )
{
  CORBA::Request_var _req = this->_request( "openURL" );
  _req->add_in_arg( "url" ) <<= CORBA::Any::from_string( (char *) url, 0 );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->invoke();
  #ifdef HAVE_EXCEPTIONS
  if( _req->env()->exception() ) {
    CORBA::Exception *_ex = _req->env()->exception();
    CORBA::UnknownUserException *_uuex = CORBA::UnknownUserException::_narrow( _ex );
    if( _uuex ) {
      mico_throw( CORBA::UNKNOWN() );
    } else {
      mico_throw( *_ex );
    }
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotSplitView()
{
  CORBA::Request_var _req = this->_request( "slotSplitView" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotShowDot()
{
  CORBA::Request_var _req = this->_request( "slotShowDot" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotLargeIcons()
{
  CORBA::Request_var _req = this->_request( "slotLargeIcons" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotSmallIcons()
{
  CORBA::Request_var _req = this->_request( "slotSmallIcons" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotTreeView()
{
  CORBA::Request_var _req = this->_request( "slotTreeView" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotHTMLView()
{
  CORBA::Request_var _req = this->_request( "slotHTMLView" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotSaveGeometry()
{
  CORBA::Request_var _req = this->_request( "slotSaveGeometry" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotShowCache()
{
  CORBA::Request_var _req = this->_request( "slotShowCache" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotShowHistory()
{
  CORBA::Request_var _req = this->_request( "slotShowHistory" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotOpenLocation()
{
  CORBA::Request_var _req = this->_request( "slotOpenLocation" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotConfigureKeys()
{
  CORBA::Request_var _req = this->_request( "slotConfigureKeys" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotAboutApp()
{
  CORBA::Request_var _req = this->_request( "slotAboutApp" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotURLEntered()
{
  CORBA::Request_var _req = this->_request( "slotURLEntered" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotStop()
{
  CORBA::Request_var _req = this->_request( "slotStop" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotNewWindow()
{
  CORBA::Request_var _req = this->_request( "slotNewWindow" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotUp()
{
  CORBA::Request_var _req = this->_request( "slotUp" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotHome()
{
  CORBA::Request_var _req = this->_request( "slotHome" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotBack()
{
  CORBA::Request_var _req = this->_request( "slotBack" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotForward()
{
  CORBA::Request_var _req = this->_request( "slotForward" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotReload()
{
  CORBA::Request_var _req = this->_request( "slotReload" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotFileNewActivated( CORBA::Long id )
{
  CORBA::Request_var _req = this->_request( "slotFileNewActivated" );
  _req->add_in_arg( "id" ) <<= id;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotFileNewAboutToShow()
{
  CORBA::Request_var _req = this->_request( "slotFileNewAboutToShow" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotBookmarkSelected( CORBA::Long id )
{
  CORBA::Request_var _req = this->_request( "slotBookmarkSelected" );
  _req->add_in_arg( "id" ) <<= id;
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


void KFM::Part_stub::slotEditBookmarks()
{
  CORBA::Request_var _req = this->_request( "slotEditBookmarks" );
  _req->result()->value()->type( CORBA::_tc_void );
  _req->send_oneway();
  #ifdef HAVE_EXCEPTIONS
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      mico_throw( *_ex );
  }
  #else
  {
    CORBA::Exception *_ex;
    if( (_ex = _req->env()->exception()) )
      CORBA::Exception::_throw_failed( _ex );
  }
  #endif
}


struct _global_init_KFM_Part {
  _global_init_KFM_Part()
  {
    if( ::OpenParts::Part::_narrow_helpers == NULL )
      ::OpenParts::Part::_narrow_helpers = new vector<CORBA::Narrow_proto>;
    ::OpenParts::Part::_narrow_helpers->push_back( KFM::Part::_narrow_helper2 );
  }
} __global_init_KFM_Part;

#ifdef HAVE_NAMESPACE
namespace KFM { vector<CORBA::Narrow_proto> * Part::_narrow_helpers; };
#else
vector<CORBA::Narrow_proto> * KFM::Part::_narrow_helpers;
#endif
#ifdef HAVE_NAMESPACE
namespace KFM { CORBA::TypeCodeConst _tc_Part; };
#else
CORBA::TypeCodeConst KFM::_tc_Part;
#endif

CORBA::Boolean
operator<<=( CORBA::Any &_a, const KFM::Part_ptr _obj )
{
  return (_a <<= CORBA::Any::from_object( _obj, "Part" ));
}

CORBA::Boolean
operator>>=( const CORBA::Any &_a, KFM::Part_ptr &_obj )
{
  CORBA::Object_ptr _o;
  if( !(_a >>= CORBA::Any::to_object( _o )) )
    return FALSE;
  if( CORBA::is_nil( _o ) ) {
    _obj = ::KFM::Part::_nil();
    return TRUE;
  }
  _obj = ::KFM::Part::_narrow( _o );
  CORBA::release( _o );
  return TRUE;
}


// Stub interface MainWindow
KFM::MainWindow::~MainWindow()
{
}

KFM::MainWindow_ptr KFM::MainWindow::_duplicate( MainWindow_ptr _obj )
{
  if( !CORBA::is_nil( _obj ) )
    _obj->_ref();
  return _obj;
}

void *KFM::MainWindow::_narrow_helper( const char *_repoid )
{
  if( strcmp( _repoid, "IDL:KFM/MainWindow:1.0" ) == 0 )
    return (void *)this;
  {
    void *_p;
    if( (_p = OpenParts::MainWindow::_narrow_helper( _repoid )))
      return _p;
  }
  return NULL;
}

bool KFM::MainWindow::_narrow_helper2( CORBA::Object_ptr _obj )
{
  if( strcmp( _obj->_repoid(), "IDL:KFM/MainWindow:1.0" ) == 0) {
    return true;
  }
  for( vector<CORBA::Narrow_proto>::size_type _i = 0;
       _narrow_helpers && _i < _narrow_helpers->size(); _i++ ) {
    bool _res = (*(*_narrow_helpers)[ _i ])( _obj );
    if( _res )
      return true;
  }
  return false;
}

KFM::MainWindow_ptr KFM::MainWindow::_narrow( CORBA::Object_ptr _obj )
{
  KFM::MainWindow_ptr _o;
  if( !CORBA::is_nil( _obj ) ) {
    void *_p;
    if( (_p = _obj->_narrow_helper( "IDL:KFM/MainWindow:1.0" )))
      return _duplicate( (KFM::MainWindow_ptr) _p );
    if( _narrow_helper2( _obj ) ) {
      _o = new KFM::MainWindow_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
    if( _obj->_is_a_remote( "IDL:KFM/MainWindow:1.0" ) ) {
      _o = new KFM::MainWindow_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
  }
  return _nil();
}

KFM::MainWindow_ptr KFM::MainWindow::_nil()
{
  return NULL;
}

KFM::MainWindow_stub::~MainWindow_stub()
{
}

struct _global_init_KFM_MainWindow {
  _global_init_KFM_MainWindow()
  {
    if( ::OpenParts::MainWindow::_narrow_helpers == NULL )
      ::OpenParts::MainWindow::_narrow_helpers = new vector<CORBA::Narrow_proto>;
    ::OpenParts::MainWindow::_narrow_helpers->push_back( KFM::MainWindow::_narrow_helper2 );
  }
} __global_init_KFM_MainWindow;

#ifdef HAVE_NAMESPACE
namespace KFM { vector<CORBA::Narrow_proto> * MainWindow::_narrow_helpers; };
#else
vector<CORBA::Narrow_proto> * KFM::MainWindow::_narrow_helpers;
#endif
#ifdef HAVE_NAMESPACE
namespace KFM { CORBA::TypeCodeConst _tc_MainWindow; };
#else
CORBA::TypeCodeConst KFM::_tc_MainWindow;
#endif

CORBA::Boolean
operator<<=( CORBA::Any &_a, const KFM::MainWindow_ptr _obj )
{
  return (_a <<= CORBA::Any::from_object( _obj, "MainWindow" ));
}

CORBA::Boolean
operator>>=( const CORBA::Any &_a, KFM::MainWindow_ptr &_obj )
{
  CORBA::Object_ptr _o;
  if( !(_a >>= CORBA::Any::to_object( _o )) )
    return FALSE;
  if( CORBA::is_nil( _o ) ) {
    _obj = ::KFM::MainWindow::_nil();
    return TRUE;
  }
  _obj = ::KFM::MainWindow::_narrow( _o );
  CORBA::release( _o );
  return TRUE;
}


// Stub interface Application
KFM::Application::~Application()
{
}

KFM::Application_ptr KFM::Application::_duplicate( Application_ptr _obj )
{
  if( !CORBA::is_nil( _obj ) )
    _obj->_ref();
  return _obj;
}

void *KFM::Application::_narrow_helper( const char *_repoid )
{
  if( strcmp( _repoid, "IDL:KFM/Application:1.0" ) == 0 )
    return (void *)this;
  {
    void *_p;
    if( (_p = OpenParts::Application::_narrow_helper( _repoid )))
      return _p;
  }
  return NULL;
}

bool KFM::Application::_narrow_helper2( CORBA::Object_ptr _obj )
{
  if( strcmp( _obj->_repoid(), "IDL:KFM/Application:1.0" ) == 0) {
    return true;
  }
  for( vector<CORBA::Narrow_proto>::size_type _i = 0;
       _narrow_helpers && _i < _narrow_helpers->size(); _i++ ) {
    bool _res = (*(*_narrow_helpers)[ _i ])( _obj );
    if( _res )
      return true;
  }
  return false;
}

KFM::Application_ptr KFM::Application::_narrow( CORBA::Object_ptr _obj )
{
  KFM::Application_ptr _o;
  if( !CORBA::is_nil( _obj ) ) {
    void *_p;
    if( (_p = _obj->_narrow_helper( "IDL:KFM/Application:1.0" )))
      return _duplicate( (KFM::Application_ptr) _p );
    if( _narrow_helper2( _obj ) ) {
      _o = new KFM::Application_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
    if( _obj->_is_a_remote( "IDL:KFM/Application:1.0" ) ) {
      _o = new KFM::Application_stub;
      _o->MICO_SCOPE(CORBA,Object::operator=)( *_obj );
      return _o;
    }
  }
  return _nil();
}

KFM::Application_ptr KFM::Application::_nil()
{
  return NULL;
}

KFM::Application_stub::~Application_stub()
{
}

struct _global_init_KFM_Application {
  _global_init_KFM_Application()
  {
    if( ::OpenParts::Application::_narrow_helpers == NULL )
      ::OpenParts::Application::_narrow_helpers = new vector<CORBA::Narrow_proto>;
    ::OpenParts::Application::_narrow_helpers->push_back( KFM::Application::_narrow_helper2 );
  }
} __global_init_KFM_Application;

#ifdef HAVE_NAMESPACE
namespace KFM { vector<CORBA::Narrow_proto> * Application::_narrow_helpers; };
#else
vector<CORBA::Narrow_proto> * KFM::Application::_narrow_helpers;
#endif
#ifdef HAVE_NAMESPACE
namespace KFM { CORBA::TypeCodeConst _tc_Application; };
#else
CORBA::TypeCodeConst KFM::_tc_Application;
#endif

CORBA::Boolean
operator<<=( CORBA::Any &_a, const KFM::Application_ptr _obj )
{
  return (_a <<= CORBA::Any::from_object( _obj, "Application" ));
}

CORBA::Boolean
operator>>=( const CORBA::Any &_a, KFM::Application_ptr &_obj )
{
  CORBA::Object_ptr _o;
  if( !(_a >>= CORBA::Any::to_object( _o )) )
    return FALSE;
  if( CORBA::is_nil( _o ) ) {
    _obj = ::KFM::Application::_nil();
    return TRUE;
  }
  _obj = ::KFM::Application::_narrow( _o );
  CORBA::release( _o );
  return TRUE;
}

struct __tc_init_KFM {
  __tc_init_KFM()
  {
    KFM::_tc_Part = "010000000e00000025000000010000001100000049444c3a4b464d2f5061"
    "72743a312e3000000000050000005061727400";
    KFM::_tc_MainWindow = "010000000e0000002f000000010000001700000049444c3a4b464d2f4d61"
    "696e57696e646f773a312e3000000b0000004d61696e57696e646f7700";
    KFM::_tc_Application = "010000000e00000030000000010000001800000049444c3a4b464d2f4170"
    "706c69636174696f6e3a312e30000c0000004170706c69636174696f6e00"
    ;
  }
};

static __tc_init_KFM __init_KFM;

//--------------------------------------------------------
//  Implementation of skeletons
//--------------------------------------------------------

// Dynamic Implementation Routine for interface Part
KFM::Part_skel::Part_skel( const CORBA::BOA::ReferenceData &_id )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KFM/Part:1.0", "Part" );
  assert( !CORBA::is_nil( _impl ) );
  _create_ref( _id,
    CORBA::InterfaceDef::_nil(),
    _impl,
    "IDL:KFM/Part:1.0" );
  register_dispatcher( new InterfaceDispatcherWrapper<Part_skel>( this ) );
}

KFM::Part_skel::Part_skel( CORBA::Object_ptr _obj )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KFM/Part:1.0", "Part" );
  assert( !CORBA::is_nil( _impl ) );
  _restore_ref( _obj,
    CORBA::BOA::ReferenceData(),
    CORBA::InterfaceDef::_nil(),
    _impl );
  register_dispatcher( new InterfaceDispatcherWrapper<Part_skel>( this ) );
}

KFM::Part_skel::~Part_skel()
{
}

bool KFM::Part_skel::dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment & /*_env*/ )
{
  if( strcmp( _req->op_name(), "openURL" ) == 0 ) {
    CORBA::String_var url;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( CORBA::_tc_string );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= CORBA::Any::to_string( url, 0 );
    #ifdef HAVE_EXCEPTIONS
    try {
    #endif
      openURL( url );
    #ifdef HAVE_EXCEPTIONS
    } catch( CORBA::SystemException_var &_ex ) {
      _req->exception( _ex->_clone() );
      return true;
    } catch( ... ) {
      assert( 0 );
      return true;
    }
    #endif
    return true;
  }
  if( strcmp( _req->op_name(), "slotSplitView" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotSplitView();
    return true;
  }
  if( strcmp( _req->op_name(), "slotShowDot" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotShowDot();
    return true;
  }
  if( strcmp( _req->op_name(), "slotLargeIcons" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotLargeIcons();
    return true;
  }
  if( strcmp( _req->op_name(), "slotSmallIcons" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotSmallIcons();
    return true;
  }
  if( strcmp( _req->op_name(), "slotTreeView" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotTreeView();
    return true;
  }
  if( strcmp( _req->op_name(), "slotHTMLView" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotHTMLView();
    return true;
  }
  if( strcmp( _req->op_name(), "slotSaveGeometry" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotSaveGeometry();
    return true;
  }
  if( strcmp( _req->op_name(), "slotShowCache" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotShowCache();
    return true;
  }
  if( strcmp( _req->op_name(), "slotShowHistory" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotShowHistory();
    return true;
  }
  if( strcmp( _req->op_name(), "slotOpenLocation" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotOpenLocation();
    return true;
  }
  if( strcmp( _req->op_name(), "slotConfigureKeys" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotConfigureKeys();
    return true;
  }
  if( strcmp( _req->op_name(), "slotAboutApp" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotAboutApp();
    return true;
  }
  if( strcmp( _req->op_name(), "slotURLEntered" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotURLEntered();
    return true;
  }
  if( strcmp( _req->op_name(), "slotStop" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotStop();
    return true;
  }
  if( strcmp( _req->op_name(), "slotNewWindow" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotNewWindow();
    return true;
  }
  if( strcmp( _req->op_name(), "slotUp" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotUp();
    return true;
  }
  if( strcmp( _req->op_name(), "slotHome" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotHome();
    return true;
  }
  if( strcmp( _req->op_name(), "slotBack" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotBack();
    return true;
  }
  if( strcmp( _req->op_name(), "slotForward" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotForward();
    return true;
  }
  if( strcmp( _req->op_name(), "slotReload" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotReload();
    return true;
  }
  if( strcmp( _req->op_name(), "slotFileNewActivated" ) == 0 ) {
    CORBA::Long id;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( CORBA::_tc_long );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= id;
    slotFileNewActivated( id );
    return true;
  }
  if( strcmp( _req->op_name(), "slotFileNewAboutToShow" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotFileNewAboutToShow();
    return true;
  }
  if( strcmp( _req->op_name(), "slotBookmarkSelected" ) == 0 ) {
    CORBA::Long id;

    CORBA::NVList_ptr _args = new CORBA::NVList (1);
    _args->add( CORBA::ARG_IN );
    _args->item( 0 )->value()->type( CORBA::_tc_long );

    if (!_req->params( _args ))
      return true;

    *_args->item( 0 )->value() >>= id;
    slotBookmarkSelected( id );
    return true;
  }
  if( strcmp( _req->op_name(), "slotEditBookmarks" ) == 0 ) {
    CORBA::NVList_ptr _args = new CORBA::NVList (0);

    if (!_req->params( _args ))
      return true;

    slotEditBookmarks();
    return true;
  }
  return false;
}

KFM::Part_ptr KFM::Part_skel::_this()
{
  return KFM::Part::_duplicate( this );
}


// Dynamic Implementation Routine for interface MainWindow
KFM::MainWindow_skel::MainWindow_skel( const CORBA::BOA::ReferenceData &_id )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KFM/MainWindow:1.0", "MainWindow" );
  assert( !CORBA::is_nil( _impl ) );
  _create_ref( _id,
    CORBA::InterfaceDef::_nil(),
    _impl,
    "IDL:KFM/MainWindow:1.0" );
  register_dispatcher( new InterfaceDispatcherWrapper<MainWindow_skel>( this ) );
}

KFM::MainWindow_skel::MainWindow_skel( CORBA::Object_ptr _obj )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KFM/MainWindow:1.0", "MainWindow" );
  assert( !CORBA::is_nil( _impl ) );
  _restore_ref( _obj,
    CORBA::BOA::ReferenceData(),
    CORBA::InterfaceDef::_nil(),
    _impl );
  register_dispatcher( new InterfaceDispatcherWrapper<MainWindow_skel>( this ) );
}

KFM::MainWindow_skel::~MainWindow_skel()
{
}

bool KFM::MainWindow_skel::dispatch( CORBA::ServerRequest_ptr /*_req*/, CORBA::Environment & /*_env*/ )
{
  return false;
}

KFM::MainWindow_ptr KFM::MainWindow_skel::_this()
{
  return KFM::MainWindow::_duplicate( this );
}


// Dynamic Implementation Routine for interface Application
KFM::Application_skel::Application_skel( const CORBA::BOA::ReferenceData &_id )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KFM/Application:1.0", "Application" );
  assert( !CORBA::is_nil( _impl ) );
  _create_ref( _id,
    CORBA::InterfaceDef::_nil(),
    _impl,
    "IDL:KFM/Application:1.0" );
  register_dispatcher( new InterfaceDispatcherWrapper<Application_skel>( this ) );
}

KFM::Application_skel::Application_skel( CORBA::Object_ptr _obj )
{
  CORBA::ImplementationDef_var _impl =
    _find_impl( "IDL:KFM/Application:1.0", "Application" );
  assert( !CORBA::is_nil( _impl ) );
  _restore_ref( _obj,
    CORBA::BOA::ReferenceData(),
    CORBA::InterfaceDef::_nil(),
    _impl );
  register_dispatcher( new InterfaceDispatcherWrapper<Application_skel>( this ) );
}

KFM::Application_skel::~Application_skel()
{
}

bool KFM::Application_skel::dispatch( CORBA::ServerRequest_ptr /*_req*/, CORBA::Environment & /*_env*/ )
{
  return false;
}

KFM::Application_ptr KFM::Application_skel::_this()
{
  return KFM::Application::_duplicate( this );
}

