/*
 *  MICO --- a free CORBA implementation
 *  Copyright (C) 1997-98 Kay Roemer & Arno Puder
 *
 *  This file was automatically generated. DO NOT EDIT!
 */

#if !defined(__KFM_H__) || defined(MICO_NO_TOPLEVEL_MODULES)
#define __KFM_H__

#ifndef MICO_NO_TOPLEVEL_MODULES
#include <CORBA.h>
#include <mico/throw.h>
#endif

#ifdef MICO_IN_GENERATED_CODE
#include <kom.h>
#else
#define MICO_IN_GENERATED_CODE
#include <kom.h>
#undef MICO_IN_GENERATED_CODE
#endif

#ifdef MICO_IN_GENERATED_CODE
#include <openparts_ui.h>
#else
#define MICO_IN_GENERATED_CODE
#include <openparts_ui.h>
#undef MICO_IN_GENERATED_CODE
#endif

#ifdef MICO_IN_GENERATED_CODE
#include <openparts.h>
#else
#define MICO_IN_GENERATED_CODE
#include <openparts.h>
#undef MICO_IN_GENERATED_CODE
#endif

#ifndef MICO_NO_TOPLEVEL_MODULES
MICO_NAMESPACE_DECL KFM {
#endif

#if !defined(MICO_NO_TOPLEVEL_MODULES) || defined(MICO_MODULE_KFM)


class Part;
typedef Part *Part_ptr;
typedef Part_ptr PartRef;
typedef ObjVar<Part> Part_var;
typedef Part_var Part_out;


// Common definitions for interface Part
class Part : 
  virtual public ::OpenParts::Part
{
  public:
    virtual ~Part();
    static Part_ptr _duplicate( Part_ptr obj );
    static Part_ptr _narrow( CORBA::Object_ptr obj );
    static Part_ptr _nil();

    virtual void *_narrow_helper( const char *repoid );
    static vector<CORBA::Narrow_proto> *_narrow_helpers;
    static bool _narrow_helper2( CORBA::Object_ptr obj );

    virtual void openURL( const char* url ) = 0;
    virtual void slotSplitView() = 0;
    virtual void slotShowDot() = 0;
    virtual void slotLargeIcons() = 0;
    virtual void slotSmallIcons() = 0;
    virtual void slotTreeView() = 0;
    virtual void slotHTMLView() = 0;
    virtual void slotSaveGeometry() = 0;
    virtual void slotShowCache() = 0;
    virtual void slotShowHistory() = 0;
    virtual void slotOpenLocation() = 0;
    virtual void slotConfigureKeys() = 0;
    virtual void slotAboutApp() = 0;
    virtual void slotURLEntered() = 0;
    virtual void slotStop() = 0;
    virtual void slotNewWindow() = 0;
    virtual void slotUp() = 0;
    virtual void slotHome() = 0;
    virtual void slotBack() = 0;
    virtual void slotForward() = 0;
    virtual void slotReload() = 0;
    virtual void slotFileNewActivated( CORBA::Long id ) = 0;
    virtual void slotFileNewAboutToShow() = 0;
    virtual void slotBookmarkSelected( CORBA::Long id ) = 0;
    virtual void slotEditBookmarks() = 0;
  protected:
    Part() {};
  private:
    Part( const Part& );
    void operator=( const Part& );
};

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_Part;

// Stub for interface Part
class Part_stub : virtual public Part,
  virtual public ::OpenParts::Part_stub
{
  public:
    virtual ~Part_stub();
    void openURL( const char* url );
    void slotSplitView();
    void slotShowDot();
    void slotLargeIcons();
    void slotSmallIcons();
    void slotTreeView();
    void slotHTMLView();
    void slotSaveGeometry();
    void slotShowCache();
    void slotShowHistory();
    void slotOpenLocation();
    void slotConfigureKeys();
    void slotAboutApp();
    void slotURLEntered();
    void slotStop();
    void slotNewWindow();
    void slotUp();
    void slotHome();
    void slotBack();
    void slotForward();
    void slotReload();
    void slotFileNewActivated( CORBA::Long id );
    void slotFileNewAboutToShow();
    void slotBookmarkSelected( CORBA::Long id );
    void slotEditBookmarks();
  private:
    void operator=( const Part_stub& );
};

class Part_skel :
  virtual public MethodDispatcher,
  virtual public Part
{
  public:
    Part_skel( const CORBA::BOA::ReferenceData & = CORBA::BOA::ReferenceData() );
    virtual ~Part_skel();
    Part_skel( CORBA::Object_ptr obj );
    virtual bool dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment &_env );
    Part_ptr _this();

};

class MainWindow;
typedef MainWindow *MainWindow_ptr;
typedef MainWindow_ptr MainWindowRef;
typedef ObjVar<MainWindow> MainWindow_var;
typedef MainWindow_var MainWindow_out;


// Common definitions for interface MainWindow
class MainWindow : 
  virtual public ::OpenParts::MainWindow
{
  public:
    virtual ~MainWindow();
    static MainWindow_ptr _duplicate( MainWindow_ptr obj );
    static MainWindow_ptr _narrow( CORBA::Object_ptr obj );
    static MainWindow_ptr _nil();

    virtual void *_narrow_helper( const char *repoid );
    static vector<CORBA::Narrow_proto> *_narrow_helpers;
    static bool _narrow_helper2( CORBA::Object_ptr obj );

  protected:
    MainWindow() {};
  private:
    MainWindow( const MainWindow& );
    void operator=( const MainWindow& );
};

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_MainWindow;

// Stub for interface MainWindow
class MainWindow_stub : virtual public MainWindow,
  virtual public ::OpenParts::MainWindow_stub
{
  public:
    virtual ~MainWindow_stub();
  private:
    void operator=( const MainWindow_stub& );
};

class MainWindow_skel :
  virtual public MethodDispatcher,
  virtual public MainWindow
{
  public:
    MainWindow_skel( const CORBA::BOA::ReferenceData & = CORBA::BOA::ReferenceData() );
    virtual ~MainWindow_skel();
    MainWindow_skel( CORBA::Object_ptr obj );
    virtual bool dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment &_env );
    MainWindow_ptr _this();

};

class Application;
typedef Application *Application_ptr;
typedef Application_ptr ApplicationRef;
typedef ObjVar<Application> Application_var;
typedef Application_var Application_out;


// Common definitions for interface Application
class Application : 
  virtual public ::OpenParts::Application
{
  public:
    virtual ~Application();
    static Application_ptr _duplicate( Application_ptr obj );
    static Application_ptr _narrow( CORBA::Object_ptr obj );
    static Application_ptr _nil();

    virtual void *_narrow_helper( const char *repoid );
    static vector<CORBA::Narrow_proto> *_narrow_helpers;
    static bool _narrow_helper2( CORBA::Object_ptr obj );

  protected:
    Application() {};
  private:
    Application( const Application& );
    void operator=( const Application& );
};

MICO_EXPORT_VAR_DECL CORBA::TypeCodeConst _tc_Application;

// Stub for interface Application
class Application_stub : virtual public Application,
  virtual public ::OpenParts::Application_stub
{
  public:
    virtual ~Application_stub();
  private:
    void operator=( const Application_stub& );
};

class Application_skel :
  virtual public MethodDispatcher,
  virtual public Application
{
  public:
    Application_skel( const CORBA::BOA::ReferenceData & = CORBA::BOA::ReferenceData() );
    virtual ~Application_skel();
    Application_skel( CORBA::Object_ptr obj );
    virtual bool dispatch( CORBA::ServerRequest_ptr _req, CORBA::Environment &_env );
    Application_ptr _this();

};

#endif // !defined(MICO_NO_TOPLEVEL_MODULES) || defined(MICO_MODULE_KFM)

#ifndef MICO_NO_TOPLEVEL_MODULES

};
#endif



#if !defined(MICO_NO_TOPLEVEL_MODULES) || defined(MICO_MODULE__GLOBAL)

CORBA::Boolean operator<<=( CORBA::Any &a, const KFM::Part_ptr obj );
CORBA::Boolean operator>>=( const CORBA::Any &a, KFM::Part_ptr &obj );

CORBA::Boolean operator<<=( CORBA::Any &a, const KFM::MainWindow_ptr obj );
CORBA::Boolean operator>>=( const CORBA::Any &a, KFM::MainWindow_ptr &obj );

CORBA::Boolean operator<<=( CORBA::Any &a, const KFM::Application_ptr obj );
CORBA::Boolean operator>>=( const CORBA::Any &a, KFM::Application_ptr &obj );

#endif // !defined(MICO_NO_TOPLEVEL_MODULES) || defined(MICO_MODULE__GLOBAL)


#if !defined(MICO_NO_TOPLEVEL_MODULES) && !defined(MICO_IN_GENERATED_CODE)
#include <mico/template_impl.h>
#endif

#endif
