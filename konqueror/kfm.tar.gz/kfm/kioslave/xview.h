#ifndef XVIEW_H
#define XVIEW_H

#include <qimage.h>
#include <qpixmap.h>

void write_xv_file( const char *_filename, QPixmap &_pixmap );

#endif
