
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <klocale.h>
#include <kapp.h>
#include <kbind.h>
#include <klined.h>

#include "kfmdlg.h"
#include "kURLcompletion.h"
#include "open-with.h"

DlgLineEntry::DlgLineEntry( const QString&_text, const QString& _value, QWidget *parent, bool _file_mode )
        : QDialog( parent, 0L, true )
{
    setGeometry( x(), y(), 350, 100 );
    setFocusPolicy(StrongFocus);

    QLabel *label = new QLabel( _text , this );
    label->setGeometry( 10, 10, 330, 15 );

    edit = new KLined( this, 0L );
    
    if ( _file_mode ) {
        completion = new KURLCompletion();
	connect ( edit, SIGNAL (completion()),
		  completion, SLOT (make_completion()));
	connect ( edit, SIGNAL (rotation()),
		  completion, SLOT (make_rotation()));
	connect ( edit, SIGNAL (textChanged(const QString&)),
		  completion, SLOT (edited(const QString&)));
	connect ( completion, SIGNAL (setText (const QString&)),
		  edit, SLOT (setText (const QString&)));
    }
    else
	    completion = 0L;

    edit->setGeometry( 10, 40, 330, 25 );
    connect( edit, SIGNAL(returnPressed()), SLOT(accept()) );

    QPushButton *ok;
    QPushButton *clear;
    QPushButton *cancel;
    ok = new QPushButton( i18n("OK"), this );
    ok->setGeometry( 10,70, 80,25 );
    ok->setDefault(TRUE);
    connect( ok, SIGNAL(clicked()), SLOT(accept()) );

    clear = new QPushButton( i18n("Clear"), this );
    clear->setGeometry( 135, 70, 80, 25 );
    connect( clear, SIGNAL(clicked()), SLOT(slotClear()) );

    cancel = new QPushButton( i18n("Cancel"), this );
    cancel->setGeometry( 260, 70, 80, 25 );
    connect( cancel, SIGNAL(clicked()), SLOT(reject()) );

    edit->setText( _value );
    edit->setFocus();
}

DlgLineEntry::~DlgLineEntry()
{
	delete completion;
}

void DlgLineEntry::slotClear()
{
    edit->setText("");
}

/***************************************************************
 *
 * OpenWithDlg
 *
 ***************************************************************/

OpenWithDlg::OpenWithDlg( const QString&_text, const QString& _value, QWidget *parent, bool _file_mode )
        : QDialog( parent, 0L, true )
{
  m_pTree = 0L;
  m_pBind = 0L;
  haveApp = false;
  
  setGeometry( x(), y(), 370, 100 );
  setFocusPolicy(StrongFocus);

  label = new QLabel( _text , this );
  label->setGeometry( 10, 10, 350, 15 );
  
  edit = new KLined( this, 0L );
    
  if ( _file_mode )
  {
    completion = new KURLCompletion();
    connect ( edit, SIGNAL (completion()),
	      completion, SLOT (make_completion()));
    connect ( edit, SIGNAL (rotation()),
	      completion, SLOT (make_rotation()));
    connect ( edit, SIGNAL (textChanged(const QString&)),
	      completion, SLOT (edited(const QString&)));
    connect ( completion, SIGNAL (setText (const QString&)),
	      edit, SLOT (setText (const QString&)));
  }
  else
    completion = 0L;

  edit->setGeometry( 10, 35, 350, 25 );
  connect( edit, SIGNAL(returnPressed()), SLOT(accept()) );
  
  ok = new QPushButton( i18n("OK"), this );
  ok->setGeometry( 10,70, 80,25 );
  ok->setDefault(TRUE);
  connect( ok, SIGNAL(clicked()), SLOT(slotOK()) );
  
  browse = new QPushButton( i18n("&Browser"), this );
  browse->setGeometry( 100, 70, 80, 25 );
  connect( browse, SIGNAL(clicked()), SLOT(slotBrowse()) );
  
  clear = new QPushButton( i18n("Clear"), this );
  clear->setGeometry( 190, 70, 80, 25 );
  connect( clear, SIGNAL(clicked()), SLOT(slotClear()) );
  
  cancel = new QPushButton( i18n("Cancel"), this );
  cancel->setGeometry( 280, 70, 80, 25 );
  connect( cancel, SIGNAL(clicked()), SLOT(reject()) );
  
  edit->setText( _value );
  edit->setFocus();
  haveApp = false;
}

OpenWithDlg::~OpenWithDlg()
{
  delete completion;
}

void OpenWithDlg::slotClear()
{
  edit->setText("");
}

void OpenWithDlg::slotBrowse()
{
  if ( m_pTree )
    return;
  
  browse->setEnabled( false );

  ok->setGeometry( 10,280, 80,25 );
  browse->setGeometry( 100, 280, 80, 25 );
  clear->setGeometry( 190, 280, 80, 25 );
  cancel->setGeometry( 280, 280, 80, 25 );

  m_pTree = new KApplicationTree( this );
  connect( m_pTree, SIGNAL( selected( const QString&, const QString& ) ), this, SLOT( slotSelected( const QString&, const QString& ) ) );

  connect( m_pTree, SIGNAL( highlighted( const QString&, const QString&) ), this, SLOT( slotHighlighted( const QString&, const QString& ) ) );

  m_pTree->setGeometry( 10, 70, 350, 200 );
  m_pTree->show();
  m_pTree->setFocus();
  
  resize( width(), height() + 210 );
}

void OpenWithDlg::resizeEvent(QResizeEvent *){

  // someone will have to write proper geometry management 
  // but for now this will have to do ....

  if(m_pTree){

    label->setGeometry( 10, 10, width() - 20, 15 );
    edit->setGeometry( 10, 35, width() - 20, 25 );
    ok->setGeometry( 10,height() - 30, (width()-20-30)/4,25 );
    browse->setGeometry( 10 + (width()-20-30)/4 + 10
			 ,height() - 30, (width()-20-30)/4, 25 );
    clear->setGeometry(10 + 2*((width()-20-30)/4) + 2*10 
		       ,height() - 30, (width()-20-30)/4, 25 );
    cancel->setGeometry( 10 + 3*((width()-20-30)/4) + 3*10 ,
			 height() - 30, (width()-20-30)/4, 25 );
    m_pTree->setGeometry( 10, 70, width() - 20, height() - 110 );

  }
  else{

    label->setGeometry( 10, 10, width() - 20, 15 );
    edit->setGeometry( 10, 35, width() - 20, 25 );
    ok->setGeometry( 10,height() - 30, (width()-20-30)/4,25);
    browse->setGeometry( 10 + (width()-20-30)/4 + 10,
			 height() - 30, (width()-20-30)/4, 25 );
    clear->setGeometry( 10 + 2*((width()-20-30)/4) + 2*10,
			height() - 30, (width()-20-30)/4, 25 );
    cancel->setGeometry( 10 + 3*((width()-20-30)/4) + 3*10,
			 height() - 30, (width()-20-30)/4, 25 );

  }
}

void OpenWithDlg::slotSelected( const QString& _name, const QString& _exec )
{
  m_pBind = KMimeBind::findByName( _name );
  if ( !m_pBind )
    edit->setText( _exec );
  else
    edit->setText( "" );

  accept();
}

void OpenWithDlg::slotHighlighted( const QString& _name, const QString& _exec )
{
  qName = _name;
  qExec = _exec;
  haveApp = true;

}


void OpenWithDlg::slotOK(){

  if(haveApp){
    m_pBind = KMimeBind::findByName( qName.data() );
  }

  haveApp = false;
  accept();
}

#include "kfmdlg.moc"

